package com.example.wiredviewer;

public class NotesThumbnailItem {
    private String note;

    public NotesThumbnailItem(String note) {
        this.note = note;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
